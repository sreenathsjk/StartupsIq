# 🚀 Startup Intelligence Engine

A production-ready AI-powered platform that automatically collects, analyzes, and presents daily startup intelligence — built for founders and investors.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    DAILY CRON (6 AM IST)                        │
└────────────────────────┬────────────────────────────────────────┘
                         │
              ┌──────────▼──────────┐
              │   DATA FETCHERS     │
              │  (lib/fetchers.js)  │
              └──────────┬──────────┘
                         │  Parallel fetch
        ┌────────────────┼────────────────┐
        │                │                │
   RSS Feeds          HN API         Product Hunt
   TechCrunch        Top Stories      GraphQL API
   VentureBeat       YC Jobs          GitHub Search
   Inc42 / YourStory                  Entrackr
        │                │                │
        └────────────────┼────────────────┘
                         │  ~100-300 raw items
              ┌──────────▼──────────┐
              │   AI PIPELINE       │
              │  (lib/analyzer.js)  │
              │  Claude Sonnet      │
              └──────────┬──────────┘
                         │  Structured JSON
              ┌──────────▼──────────┐
              │   DATABASE          │
              │   (Supabase)        │
              │   1 report/day      │
              └──────────┬──────────┘
                         │
              ┌──────────▼──────────┐
              │   NEXT.JS API       │
              │  /api/report (GET)  │  ← 30min memory cache
              │  /api/report (POST) │  ← Force refresh
              │  /api/history       │  ← Past reports
              └──────────┬──────────┘
                         │
              ┌──────────▼──────────┐
              │   REACT DASHBOARD   │
              │  (pages/index.jsx)  │
              │  Dark premium UI    │
              └─────────────────────┘
```

---

## Features

### Data Pipeline
- **8+ real sources**: TechCrunch, VentureBeat, HN, Product Hunt, Inc42, YourStory, Entrackr, GitHub Trending
- **Parallel fetching** with graceful fallbacks per source
- **Deduplication** by URL before AI processing
- **Cron job** runs daily at 6 AM IST (00:30 UTC)

### AI Processing (Claude Sonnet)
- Structured JSON output with deep insights
- VC-level analysis: "why now", "why this team", "what to build"
- India ecosystem context layer
- Signal strength scores (1-10) for every item
- Underrated opportunity detection
- Agentic workflow tracking

### Frontend Dashboard
- Dark premium UI with Syne + DM Sans fonts
- 9 card types: Startups, Funding, AI Tools, India, Trends, Opportunities, Ideas, Underrated, Agentic
- Rich full-detail modals for every item
- Stats bar with real counts
- 30-day report history drawer
- Performance badges (fetch time, item count, cache status)
- Skeleton loading states
- Mobile-responsive

### Performance
- 30-minute in-memory cache
- DB cache for today's report
- Force refresh via POST /api/report
- Pipeline response <2s when cached, ~30-60s when fresh

---

## Quick Start

### 1. Clone & Install

```bash
git clone <your-repo>
cd startup-intelligence-engine
npm install
```

### 2. Configure Environment

```bash
cp .env.local.example .env.local
```

Edit `.env.local`:

```env
# Required
ANTHROPIC_API_KEY=sk-ant-...
CRON_SECRET=any-random-string-here

# Required for persistence (free tier works)
NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...

# Optional (Product Hunt API — higher limits)
PRODUCT_HUNT_TOKEN=...
```

### 3. Set Up Supabase

1. Go to [supabase.com](https://supabase.com) → New Project
2. Open **SQL Editor** → paste contents of `supabase-schema.sql` → Run
3. Copy your Project URL and keys from **Settings → API**

### 4. Run Locally

```bash
npm run dev
```

Open http://localhost:3000

The first load triggers the full pipeline (~30-60s). Subsequent loads use cache.

---

## Deployment (Vercel)

### One-click deploy

```bash
npm i -g vercel
vercel --prod
```

### Add environment variables

In Vercel Dashboard → Settings → Environment Variables, add all keys from `.env.local`.

### Cron job

`vercel.json` already configures the daily cron at 00:30 UTC (6 AM IST).

To secure the cron, set the `CRON_SECRET` env var and Vercel automatically passes it as a Bearer token in the `Authorization` header.

You can also trigger manually:
```
GET https://your-app.vercel.app/api/cron?secret=YOUR_CRON_SECRET
```

---

## API Reference

### GET /api/report
Returns the latest cached report (from memory → DB → fresh pipeline).

```json
{
  "success": true,
  "data": {
    "summary": "...",
    "startups": [...],
    "funding": [...],
    "aiTools": [...],
    "indianApps": [...],
    "trends": [...],
    "opportunities": [...],
    "ideas": [...],
    "underratedOpportunities": [...],
    "agenticWorkflows": [...],
    "metadata": { "dominantTheme": "...", "indiaSignalStrength": 7 },
    "generatedAt": "2024-01-15T06:30:00Z",
    "itemsCount": 247,
    "fetchMs": 8420,
    "aiMs": 22100,
    "fromCache": true
  }
}
```

### POST /api/report
Force-triggers a fresh pipeline run. Use this for the manual Refresh button.

### GET /api/history
Lists available report dates.

### GET /api/history?date=2024-01-15
Returns the full report for a specific date.

---

## Customization

### Add a new RSS source
In `lib/fetchers.js`, add to `RSS_SOURCES`:
```js
{ name: "Sifted", url: "https://sifted.eu/feed", category: "global" }
```

### Adjust AI prompt
In `lib/analyzer.js`, edit `SYSTEM_PROMPT` or `CLASSIFICATION_PROMPT`. The structured JSON schema at the bottom of the prompt controls what fields are extracted.

### Add a new section type
1. Add to the JSON schema in `CLASSIFICATION_PROMPT`
2. Add renderer in `components/DetailModal.jsx`
3. Add section card in `components/sections.jsx`
4. Import and render in `pages/index.jsx`

### Change refresh schedule
In `vercel.json`, update the cron schedule (uses Unix cron syntax, UTC timezone).

---

## Cost Estimates

| Service | Free Tier | Est. Monthly (prod) |
|---------|-----------|---------------------|
| Vercel  | 100GB bandwidth | Free (Hobby) |
| Supabase | 500MB DB, 2GB bandwidth | Free |
| Anthropic (Claude) | — | ~$0.50-2/day (1 report) |
| Total | **Free** | **~$15-60/month** |

Claude Sonnet pricing: ~$3/MTok input, ~$15/MTok output. Each report uses ~25-30k tokens total.

---

## Folder Structure

```
startup-intelligence-engine/
├── lib/
│   ├── fetchers.js      # All data source fetchers (RSS, HN, PH, GitHub)
│   ├── analyzer.js      # Claude AI pipeline + prompt templates  
│   ├── pipeline.js      # Orchestrator: fetch → analyze → cache → store
│   └── db.js            # Supabase client + report CRUD
├── pages/
│   ├── index.jsx        # Main dashboard UI
│   ├── _app.js          # Next.js app wrapper
│   └── api/
│       ├── report.js    # GET/POST report endpoint
│       ├── cron.js      # Daily cron trigger
│       └── history.js   # Historical reports
├── components/
│   ├── ui.jsx           # Design system primitives
│   ├── sections.jsx     # All dashboard card components
│   ├── DetailModal.jsx  # Rich full-detail modal
│   └── LoadingSkeleton.jsx
├── styles/
│   └── globals.css      # Fonts, animations, custom utilities
├── supabase-schema.sql  # DB setup (run once)
├── vercel.json          # Cron + function config
└── .env.local.example  # All env vars documented
```

---

## Troubleshooting

**Pipeline times out on Vercel free tier?**
The free tier has a 10s function timeout. Upgrade to Vercel Pro (60s) or use background jobs. Alternatively, run the pipeline on a VPS and call it from Vercel.

**Product Hunt API returns 401?**
Get a free token at [producthunt.com/v2/oauth/applications](https://www.producthunt.com/v2/oauth/applications). Without a token, it falls back to RSS.

**AI returns invalid JSON?**
Claude Sonnet is very reliable but add try/catch around `JSON.parse`. The pipeline already does this.

**No items from some sources?**
Many RSS feeds block server-to-server requests. Add a User-Agent header in `lib/fetchers.js` if blocked.
