/**
 * pages/api/report.js
 * GET  /api/report        → returns latest cached report
 * POST /api/report        → triggers fresh pipeline run
 */

import { runPipeline } from "../../lib/pipeline.js";

export default async function handler(req, res) {
  // CORS
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  if (req.method === "OPTIONS") return res.status(200).end();

  const start = Date.now();

  try {
    if (req.method === "GET") {
      // Return cached/latest report (fast path)
      const report = await runPipeline({ force: false });
      return res.status(200).json({
        success: true,
        data: report,
        responseMs: Date.now() - start,
      });
    }

    if (req.method === "POST") {
      // Force refresh (used by the Refresh button in UI)
      console.log("[API] Force refresh triggered");
      const report = await runPipeline({ force: true });
      return res.status(200).json({
        success: true,
        data: report,
        responseMs: Date.now() - start,
      });
    }

    return res.status(405).json({ error: "Method not allowed" });
  } catch (err) {
    console.error("[API] Report error:", err.message);
    return res.status(500).json({
      success: false,
      error: err.message,
      responseMs: Date.now() - start,
    });
  }
}

// Allow long-running pipeline
export const config = {
  api: {
    responseLimit: false,
    bodyParser: true,
  },
};
