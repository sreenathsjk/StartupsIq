/**
 * pages/api/history.js
 * GET /api/history?date=2024-01-15  → specific date report
 * GET /api/history                  → list of available dates
 */

import { getReportByDate, listReportDates } from "../../lib/db.js";

export default async function handler(req, res) {
  if (req.method !== "GET") return res.status(405).end();

  const { date } = req.query;

  try {
    if (date) {
      const report = await getReportByDate(date);
      if (!report) return res.status(404).json({ error: "Report not found for this date" });
      return res.status(200).json({ success: true, data: report });
    }

    const dates = await listReportDates(30);
    return res.status(200).json({ success: true, data: dates });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
}
