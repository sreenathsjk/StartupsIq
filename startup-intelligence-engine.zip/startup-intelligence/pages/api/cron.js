/**
 * pages/api/cron.js
 * Called by Vercel Cron (configured in vercel.json) daily at 6 AM IST (00:30 UTC)
 * Also callable manually: GET /api/cron?secret=YOUR_CRON_SECRET
 */

import { runPipeline, invalidateCache } from "../../lib/pipeline.js";

export default async function handler(req, res) {
  // Security: verify cron secret
  const secret = req.headers["authorization"]?.replace("Bearer ", "") ||
    req.query.secret;

  if (secret !== process.env.CRON_SECRET) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  console.log("[Cron] Daily pipeline triggered at", new Date().toISOString());

  try {
    invalidateCache();
    const report = await runPipeline({ force: true });

    return res.status(200).json({
      success: true,
      message: "Daily report generated",
      generatedAt: report.generatedAt,
      itemsCount: report.itemsCount,
      aiMs: report.aiMs,
      fetchMs: report.fetchMs,
    });
  } catch (err) {
    console.error("[Cron] Failed:", err.message);
    return res.status(500).json({ success: false, error: err.message });
  }
}

export const config = {
  api: { responseLimit: false },
};
